package com.mfelix.grails.plugins.langSelector

class LangSelectorTagLib {

	static namespace = "langs"
		
	def selector = {attrs ->
		def values = null
		try{
			values = new ArrayList(attrs.langs.split(",").toList())
		}
		catch(Exception e){
			log.error "Error getting value of required attribute 'langs'", e
			throw new Exception("Error getting value of required attribute 'langs'. Accepted value for example is: es,en_US,en")
		}
		
		def supported = StaticConfig.config()
		def flags = [:]
		values.each { 
			def language = it.indexOf("_")>0? it.substring(0,it.indexOf("_")):it
		    def country =  it.indexOf("_")>0? it.substring(it.indexOf("_")+1,it.length()):supported[language.toLowerCase()]
		    if(country)
		    	flags[it] = country.toLowerCase()
		    else
		    	log.error "No country flag found for:"+language+" please check configuration."
		}
		//distincion de seleccionado o no por defecto estilo opacity
		def selected_class = ''
		def not_selected_class = 'opacitiy_not_selected'
		def selected = session["org.springframework.web.servlet.i18n.SessionLocaleResolver.LOCALE"]
		selected = selected?selected:Locale.getDefault()
		out << render( template:'/langSelector/selector', plugin:'langSelector',
			model:[flags:flags,
			       selected_class:selected_class,
			       not_selected_class:not_selected_class,
			       selected:selected
			       ])
	}
	
	def resources = {
		out << """
		<link rel='stylesheet' href="${resource(plugin:'langSelector',dir:'css',file:'langSelector.css')}" />
		"""
	}
	
}
